var curr = new Date().getFullYear();
var dateformat = function (id) {
    $('#'+id+'').scroller('destroy').scroller({
        preset: 'date',
        minDate: new Date(2000, 3, 10, 9, 22),
        maxDate: new Date(2017, 7, 30, 15, 44),
        // invalid: { daysOfWeek: [0, 6], daysOfMonth: ['5/1', '12/24', '12/25'] },
        //daysOfWeek 设置工作日
        theme: 'android-ics light',
        mode:'scroller',
        lang: 'zh',
        display: 'modal',
        animate: 'slidedown',
        onBeforeShow: function (inst) {
        //inst.settings.readonly = true;
            //inst.settings.readonly = true;
            $('#'+id+'').blur();
        },
        onSelect: function (valueText, inst) {
            //var selectedDate = inst.getVal(); // Call the getVal method
            //inst.settings.readonly = true;
            $('#'+id+'').blur();
        }
    });
}
