/*
common js
*/
//所有页面跳转
Zepto(function($){
    $('.data-href').click(function(e) {
       e.preventDefault();
       if($(this).data('href')){
            location.href= $(this).data('href');
        }
     });
    $('.ui-header .ui-btn').click(function(){
        location.href= 'index.html';
    });  

});
//页面加载前过渡效果
function loading(){
	$('#status').fadeOut(400);
    delay(200,preloader);
}
function preloader(){
    $('#preloader').fadeOut();
}
//延时方法
function delay(time,func){
    setTimeout(function(){func();},time);
}

//返回顶部
function goTop() {
    var obj = document.getElementById("go-top"); 
        function getScrollTop() { 
        return document.documentElement.scrollTop + document.body.scrollTop; 
        } 
    function setScrollTop(value) { 
        if (document.documentElement.scrollTop) { 
        document.documentElement.scrollTop = value; 
        } 
        else { 
        document.body.scrollTop = value; 
        } 
    } 
    window.onscroll = function() { 
    getScrollTop() > 150 ? obj.style.display = "": obj.style.display = "none"; 
    } 
        obj.onclick = function() { 
        var goTop = setInterval(scrollMove, 10); 
        function scrollMove() { 
        setScrollTop(getScrollTop() / 1.1); 
        if (getScrollTop() < 1) clearInterval(goTop); 
        } 
    } 
} 
/*按钮data-href 链接跳转重新加载 时方便调用*/
function overloaddataHref() {
    $('.data-href').click(function(e) {
       e.preventDefault();
       if($(this).data('href')){
            location.href= $(this).data('href');
        }
     });
}
/********************************************************/
/********************************************************/
//提示操作效果
function actionText(text,url){
  var html='<div class="loading-block show">'+
              '<div class="loading-cnt">'+
                  '<p>'+ text +'</p>'+
              '</div>'+
           '</div>';
      $('body').append(html);
      $('.loading-block').fadeIn();
      setTimeout(function(){$('.loading-block').fadeOut();},1000);
      setTimeout(function(){actionTextHide(url);},800);
}
function actionTextHide(url){
  setTimeout(function(){$(".loading-block").remove();},600);
  if(url != undefined && url != ''){
      location.href=''+ url +'';
  }
}

